<?php
    require_once('../simpletest/unit_tester.php');
	require_once( '../simpletest/web_tester.php' );
	require_once('../simpletest/reporter.php');
class TestOfSite extends WebTestCase{//测试类，继承自WebTestCase，web_tester.php中引入的
	function __construct(){
		parent::__construct();
	}
	function testSite(){//所有调用的函数中以assert为开头的函数都是测试用的，会返回测试结果，其余的函数多半是做模拟操作用的
		$this->get('http://localhost/thinkphp');//获取网页信息（其实是将整个页面下载下来，然后在下面的函数中进行判断），如果抓取失败，会报fetch failed的错误
		$this->assertTitle('Rifle');//判断当前获取的页面的标题是否是Rifle，是的话通过测试，否的话不通过
		$this->clickLink('Sign In');//http://localhost/thinkphp/index.php/Login/index.html
		//$this->get('http://localhost/thinkphp/index.php/Login/index.html');
		$this->assertTitle('Login/Register');//判断点击登陆按钮后跳转到的页面的标题是不是Login/Register
		$this->setField('username','micho');//将name为username的表单赋值为micho（模拟填写表单）
		$this->setField('password','123456');//将name为password的表单赋值为123456
		$this->assertSubmit('Sign In');//测试提交按钮Sign In 是否可用
		$this->clickSubmit('Sign In');//模拟点击Sign In 按钮
		$this->showRequest();//获取提交的请求的数据（form表单提交的）
		$this->assertResponse("200");//获取当前页面应答的结果是不是200（200表示成功）
		$this->showSource();//展示当前资源
		//注：以show开头的函数所展示的东西只能写一条，写多条的话前面的结果会被覆盖
	}
}
$test = new TestOfSite();//实例化TestOfSite类，然后调用父类autorun类的run方法，自动调用以test开头的方法进行测试
$test->run(new HtmlReporter());//run方法中需要传递一个类，我认为是输出测试结果的方式，htmlReporter表示用网页来输出

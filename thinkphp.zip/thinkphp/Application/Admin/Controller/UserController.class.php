<?php
namespace Admin\Controller;
use Think\Controller;
class UserController extends CommonController {
    public function _initialize(){
        parent::check();
    }
    public function index(){
    	$res=M("user")->select();
        $this->assign('res',$res);
        $this->display();
    }
    public function showdetail(){
        $id=$_GET['userid'];
        $userdetail=M("userdetail");
        $res1=M("userdetail")->where("uid={$id}")->find();
        if($res1==null){
             echo "<script>alert('该用户没有添加详细信息')</script>";
             $this->redirect('index');
        }else{
             $res=$_SESSION['admin'];
             $this->assign("res",$res);
             $this->assign("res1",$res1);
             $this->display();
        }       
    }  

    public function pay(){

        $id=$_GET['userid'];
        $data=M("sale")->where("buyer={$id}")->field('buyprice,buyname,sum(buynum)')->group('buyname,buyer')->select();
        if(count($data)==3){
            //卖出一整套商品
            foreach ($data as $key => $value) {
                $buynum[]=intval($value['sum(buynum)']);
            }
               $total=min($buynum)*100;
                if ($total<=1000) {
                   $pay=$total*0.1;
                }elseif ($total>1000 && $total<1800) {
                   $pay=$total*0.15;
                }elseif ($total>=1800) {
                   $pay=$total*0.2; 
                }
        }else{
            $this->error('暂未卖出一整套商品，无法提取佣金');
        }
        $this->assign('res',$data);
        $this->assign('pay',$pay);
        $this->display();

    }
    public function updateislogin(){
        $userid=$_GET['userid'];
        $data['islogin']=1;
        $res=M("user")->where("id={$userid}")->save($data);
        if ($res) {
            $this->redirect('index');
        }
    }
    public function noislogin(){
        $userid=$_GET['userid'];
        $data1['islogin']=0;
        $res=M("user")->where("id={$userid}")->save($data1);
        if ($res) {
            $this->redirect('index');
        }
    }

  
}
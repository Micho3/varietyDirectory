<?php
namespace Admin\Controller;
use Think\Controller;
class OrderController extends CommonController {
    public function _initialize(){
        parent::check();
    }
    public function index(){
    	$res=M("account")->select();
        $this->assign('res',$res);
        $this->display();
    }
   
    public function updateislogin(){
        $id=$_GET['id'];
        $time=strtotime($_GET['time']);
        $buyer=$_GET['buyer'];
      
        $data['status']=1;
        $res=M("account")->where("id={$id}")->save($data);
        //审核通过之后将之前的销售记录清零
        $id1=M("user")->where("username='{$buyer}'")->getField('id');

        $map['buyer']=$id1 ;
        $map['addtime']=array('lt',$time); 
        $res1=M("sale")->where($map)->delete();
        if ($res) {
            $this->redirect('index');
        }
    }
    public function noislogin(){
        $id=$_GET['id'];
        $data['status']=2;
        $res=M("account")->where("id={$id}")->save($data);
        if ($res) {
            $this->redirect('index');
        }
    }

  
}
<?php
namespace Admin\Controller;
use Think\Controller;

/**
* 作者:卜爱平
* 登录无SESSION，重新定向登录地址
*/
class CommonController extends Controller{
//初始化操作 用来检测用户的登陆信息 或者是用户端权限
	public function check(){
        $href = U('Admin/Login/index');
	 // 如果没有session的话 没有登陆
		if(empty($_SESSION['admin'])){
			echo "<script type='text/javascript'>";
			echo "window.location.href='$href'";  
			echo "</script>";
		}
	}
}
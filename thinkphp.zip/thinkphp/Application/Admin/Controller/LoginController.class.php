<?php
namespace Admin\Controller;
use Think\Controller;
class LoginController extends Controller {
    public function index(){
        $this->display();
    }
    public function loglogin(){
        $password=MD5($_POST['password']);
        $res=M("admin")->where("adminname='{$_POST['adminname']}'")->find();
       
            if ($res['password']==$password) {
                $_SESSION['admin']=$res;
                // var_dump($_SESSION['admin']);exit();
                $this->redirect("Index/index");
            }else{
                $this->error('用户名或密码错误');
            }
    }
    public function logout(){
        $_SESSION['user']=null;
        $this->redirect('Login/index');
    }
}   
<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends CommonController {
    public function _initialize(){
        parent::check();
    }
    public function index(){
    	$data=M("sale")->field('buyname,sum(buynum)')->group('buyname')->select();
        $data1=M("good")->select();
    	foreach ($data as $key => $value) {
    		$buynum[]=intval($value['sum(buynum)']);
    	}
        foreach ($data1 as $key => $value) {
            $data[$key]['price']=$value['goodprice'];
        }
     	$total=min($buynum)*100;
        
     	if ($total<=1000) {
           $pay=$total*0.1;
     	}elseif ($total>1000 && $total<1800) {
           $pay=$total*0.15;
     	}elseif ($total>=1800) {
           $pay=$total*0.2;	
     	}
        $this->assign('res',$data);
        $this->assign('pay',$pay);
        $this->display();
    }

}
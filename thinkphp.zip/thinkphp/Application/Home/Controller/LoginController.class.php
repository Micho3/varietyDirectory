<?php
namespace Home\Controller;
use Think\Controller;
class LoginController extends Controller {
    public function __construct(){
        parent::__construct();
    }
    public function index(){
        $this->display();
    }
    public function loglogin(){
        $password=MD5($_POST['password']);
        $res=M("user")->where("username='{$_POST['username']}'")->find();
        if (empty($res)) {
            $this->error('快去注册把');
        }
        if ($res['islogin']==0) {
            $this->error('您好,您的账号正在等待后台审核员审核');
        }else{
            if ($res['password']==$password) {
                $_SESSION['user']=$res;
                $this->redirect("Index/index");
            }else{
                $this->error('用户名或密码错误');
            }
        }
    }
    public function logout(){
        $_SESSION['user']=null;
        $this->redirect('Login/index');
    }
    public function isUserExists(){
        if(empty($_REQUEST['user'])) echo json_encode(array('status'=>0,'data'=>'','msg'=>'用户名为空'));exit;
        $user = $this->M("user")->where("username='{$_REQUEST['user']}'")->find();
        if(empty($user)){
            echo json_encode(array('status'=>1,'data'=>'','msg'=>'恭喜，用户名可用'));exit;
        }else{
            echo json_encode(array('status'=>1,'data'=>'','msg'=>'用户名已被注册，请重试'));exit;
        }
    }
}   
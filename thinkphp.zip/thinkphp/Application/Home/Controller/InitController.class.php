<?php
namespace Home\Controller;
use Think\Controller;
class InitController extends Controller {
    public function _initialize(){
        header("Content-type:text/html;charset=utf-8");
    	if (empty($_SESSION['user'])) {
            $this->redirect('Login/index');
        }elseif ($_SESSION['level']!=0) {
            echo "<script>alert('您不是管理员,权限不足');history.back(-1);</script>";
        }
    }
}
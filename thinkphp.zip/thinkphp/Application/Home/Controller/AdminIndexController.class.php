<?php
namespace Home\Controller;
// use Think\Controller;
class AdminIndexController extends InitController {
    public function index(){
    	$this->display();
    }
    public function main(){
    	$information['serverIp'] = GetHostByName($_SERVER['SERVER_NAME']);
		$information['serverName'] = $_SERVER['SERVER_SOFTWARE'];
		$information['phpVersion'] = PHP_VERSION;
		$information['mysqlVersion'] = mysql_get_server_info();
		$information['LoginIp'] = GetHostByName($_SERVER['SERVER_NAME']);
		$information['Domain'] = $_SERVER['SERVER_NAME'];
    	$this->assign('list',$information);
    	$this->display('main');
    }
    public function update(){
        $list = M('userdetail')->where("uid={$_GET['id']}")->find();
        $list1=M("user")->where("id={$_GET['id']}")->find();
        $this->assign('list',$list);// 赋值数据集
        $this->assign('list1',$list1);
        $this->display();
    }
    public function doaction(){
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     3145728 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload-> rootPath = "Public";
        $upload->savePath  =  '/img/'; // 设置附件上传目录    // 上传文件
        $upload->autoSub = false;
        $info   =   $upload->upload();
        if($info){
          $pic=$info['pic']['savename'];     
        }else{
          $this -> error($upload -> getError());
        }
        $data = array('phone' =>$_POST['phone'] ,'address'=>$_POST['address'],'cardid'=>$_POST['cardid'],
        'email'=>$_POST['email'],'addtime'=>time(),'pic'=>$pic);
        $data1 = array('username' => $_POST['username'] );
        $res = M('userdetail')->where("uid={$_POST['id']}")->save($data);
        $res1= M('user')->where("id={$_POST['id']}")->save($data1);
        $this->redirect('User/index');
    }
}
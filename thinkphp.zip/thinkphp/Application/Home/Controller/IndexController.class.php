<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){	
        $res=M("userdetail")->select();
        foreach ($res as $key => $value) {
           $uid=$value['uid'];
           $res[$key]['username']=M("user")->where("id={$uid}")->getfield('username');
        }
    	if ($_SESSION['user']=='') {
            $data=M("good")->select();
            $this->assign("good",$data);
            $this->display();
    	}else{
            $uid=$_SESSION['user']['id'];
            $res1=M("user_log")->where("uid={$uid}")->select();
            $data=M("good")->select();
            foreach ($res1 as $key => $value) {
                $data[$key]['num']=$value['num'];
            }
            $this->assign('good',$data);
            $this->assign('user','log');
            $this->assign('res',$res);
            $this->display();
    	}
    }
}
<?php
namespace Home\Controller;
//use Think\Controller;
class AccountController extends InitController {
    public function index(){
    	$id=$_GET['id'];
        $data=M("sale")->where("buyer={$id}")->select();
        foreach ($data as $key => $value) {
         	$res=M("userdetail")->where("uid={$id}")->getField('address');
         	$data[$key]['address']=$res;
        }
        $this->assign('row',$data);
        $this->display('main_list');
    }
    public function account(){
    	$id=$_GET['id'];
    	$data=M("sale")->where("buyer={$id}")->field('buyprice,buyname,sum(buynum)')->group('buyname,buyer')->select();
        $username=M("user")->where("id={$id}")->getField('username');
        if(count($data)==3){
            //卖出一整套商品
            foreach ($data as $key => $value) {
                $buynum[]=intval($value['sum(buynum)']);
            }
               $total=min($buynum)*100;
                if ($total<=1000) {
                   $pay=$total*0.1;
                }elseif ($total>1000 && $total<1800) {
                   $pay=$total*0.15;
                }elseif ($total>=1800) {
                   $pay=$total*0.2; 
                }
        }else{
            $this->error('暂未卖出一整套商品，快去努力把!');
        }
        $firstday = date('Y-m-01', strtotime(date("Y-m-d")));
        $lastday = date('Y-m-d', strtotime("$firstday +1 month -1 day"));
        $arrtime = array('firstday' => $firstday,'lastday'=>$lastday );
        $status=M("account")->where("username='{$username}' && applytime='$lastday'")->getField('status');
        // echo M("account")->getLastsql();
        // var_dump($status);exit();
        $this->assign('res',$data);
        $this->assign('arrtime',$arrtime);
        $this->assign('status',$status);
        $this->assign('pay',$pay);
        $this->assign('username',$username);
        $this->assign('total',min($buynum));
        $this->display('main_info');
    }

      public function getthemonth(){
       $firstday = date('Y-m-01', strtotime(date("Y-m-d")));
       //得出每个月的最后一天
       $lastday = date('Y-m-d', strtotime("$firstday +1 month -1 day"));
       //现在的日期
       $nowday=date('Y-m-d',time());
       if ($lastday==$nowday) {
          $_POST['status']=3;
          $_POST['applytime']=$lastday;
          M("account")->add($_POST);
          $this->success('申请成功');
       }else{
           $this->error('不到月底呢');
       }
    }
 

 }
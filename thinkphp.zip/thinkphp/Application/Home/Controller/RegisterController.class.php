<?php
namespace Home\Controller;
use Think\Controller;
class RegisterController extends Controller {
    public function index(){
        $this->display();
    }
    public function logregister(){
    	if ($_POST['password']!==$_POST['repassword']) {
    		$this->error('两次密码不一致');
    	}else{
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload-> rootPath = "Public";
            $upload->savePath  =  '/img/'; // 设置附件上传目录    // 上传文件
            $upload->autoSub = false;
            $info   =   $upload->upload();
            if($info){
              $pic=$info['pic']['savename'];     
            }else{
              $this -> error($upload -> getError());
            }
		    $data['password']=md5($_POST['password']);
            $data['username']=$_POST['username'];
            $uid=M("user")->add($data);
            $data1 = array('uid' =>$uid ,'gid'=>1,'num'=>70);
            $data2 = array('uid' =>$uid ,'gid'=>2,'num'=>80);
            $data3 = array('uid' =>$uid ,'gid'=>3,'num'=>90);
            M("user_log")->add($data1);
            M("user_log")->add($data2);
            M("user_log")->add($data3);
            $data4 = array('uid' =>$uid ,'phone'=>$_POST['phone'],'address'=>$_POST['address'],'pic'=>$pic
                ,'cardid'=>$_POST['cardid'],'email'=>$_POST['email'],'addtime'=>time());
            M("userdetail")->add($data4);
			$this->redirect("Login/index");    		
    	}
    }
    public function upload(){
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     3145728 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload-> rootPath = "Public";
        $upload->savePath  =  '/Uploads/'; // 设置附件上传目录    // 上传文件
        $info   =   $upload->upload();
        if($info){
             echo $info['Filedata']['savepath'].$info['Filedata']['savename'];       
        }else{
            $this -> error($upload -> getError());
        }
    }
}
<?php
namespace Home\Controller;
//use Think\Controller;
class UserController extends InitController {
    public function index(){

        $list = M('userdetail')->where("uid={$_GET['id']}")->find();// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list1=M("user")->where("id={$_GET['id']}")->find();
        $this->assign('list',$list);
        $this->assign('list1',$list1);
        $this->display('main_list');
     }

    
 }
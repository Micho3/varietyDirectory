<?php
namespace Home\Controller;
use Think\Controller;
class CartController extends Controller {
	public function index(){
		
	}
  public function doaction(){
      if (!empty($_SESSION['user'])) {
          $uid=$_SESSION['user']['id'];
          $gid=$_POST['goodid'];
          $num=M("user_log")->where("uid={$uid} and gid={$gid}")->getfield('num');
          if ($num==0) {
            $this->ajaxReturn(array('status'=>'no','message'=>'您购买商品的库存量为0'));
          }
      }else{
            $this->ajaxReturn(array('status'=>'no','message'=>'还未登陆,请先登陆'));        
      }
  }
  public function docart(){
           //购买商品的数量
           $neednum=$_POST['goodneednum'];
           //查询该销售人员还可以购买多少数量的商品
           $uid=$_SESSION['user']['id'];
           $gid=$_POST['goodid'];
           $num=M("user_log")->where("uid={$uid} and gid={$gid}")->getfield('num');
           $href = U('Index/index');
              
           if ($neednum>$num) {
              echo "<script type='text/javascript'>";
              echo "alert('您购买商品的数量超出库存量,请重新输入')";
              echo "window.location.href='$href'";  
              echo "</script>";
           }else{
              $data['num']=$num-$neednum;
              M("user_log")->where("uid={$uid} and gid={$gid}")->save($data);
              $res=M("good")->where("id={$gid}")->find();
              $data['buyer']=$uid;
              $data['buyname']=$res['goodname'];
              $data['buynum']=$neednum;
              $data['buyprice']=$res['goodprice'] ;   
              $data['addtime']=time();     
              if(M("sale")->add($data)){
                 $this->redirect("Index/index");
              }else{
                 $this->error('购买失败');
              }
           }
           
       
    }
}
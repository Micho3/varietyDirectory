<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
<head>
	<title>Rifle</title> 
	<link href="/thinkphp/Public/index/css/style.css" rel='stylesheet' type='text/css' />
	<!-- Custom Theme files -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Pricing Tables Design ,Flat Pricing Tables Design ,Popup Pricing Tables Design,Clean Pricing Tables Design "./>
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 
	</script>
	</script>
	<script src="/thinkphp/Public/Index/js/need.js"></script>
	<script type="text/javascript" src="/thinkphp/Public/Index/js/layer.m.js"></script>
</head>
<body>
	<!--start-pricing-tablel-->
	<script src="/thinkphp/Public/Index/js/jquery.magnific-popup.js" type="text/javascript">
	</script>
	<script type="text/javascript" src="/thinkphp/Public/Index/js/modernizr.custom.53451.js">
	</script> 
	<script>
			$(document).ready(function() {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
				});	
			});
	</script>	
    <div class="pricing-plans">
		<div class="wrap">
			<div class="price-head">
		 	    <!-- <a href="<?php echo U('Login/logout');?>" >Log Out</a> -->
		 	    <img src="/thinkphp/Public/Index/images/111.gif" width="30px" height="30px">
		 	    <?php if(isset($_SESSION['user'])): ?><font color="yellow">
	    		Hello，<?php echo ($_SESSION['user']['username']); ?> </font>
	    				　　<a href="<?php echo U('Login/logout');?>"><font color="yellow">[Logout]</font></a>
	    				　　<a href="<?php echo U('AdminIndex/index');?>"><font color="yellow">My Center</font></a>
	    				<?php else: ?>
	    		<a href="<?php echo U('Login/index');?>" target="_self"><font color="yellow">Sign In</font></a>　<?php endif; ?>	
		 		<h1>Rifle</h1>
		 	</div>
			<div class="pricing-grids">
			<?php if(is_array($good)): foreach($good as $key=>$vo): ?><div class="pricing-grid1">
				<div class="price-value">
				    <input id="name" type="hidden" value="<?php echo ($vo["goodname"]); ?>">
				    <input id="price" type="hidden" value="<?php echo ($vo["goodprice"]); ?>">
				    <input id="gid" type="hidden" value="<?php echo ($vo["id"]); ?>">
					<h2><a href="#"><?php echo ($vo["goodname"]); ?></a></h2>
					<h5><span>$<?php echo ($vo["goodprice"]); ?></span><lable> / per</lable></h5>
					<div class="sale-box">
						<span class="on_sale title_shop">NEW</span>
					</div>
				</div>
				<div class="price-bg">
					<ul>
						<li><img src="/thinkphp/Public/Index/images/<?php echo ($vo["goodimg"]); ?>" width="450px" height="400px"></li>

						<?php if(($user==log)): ?><li class="whyt"><a href="#">Store:<?php echo ($vo["num"]); ?></a></li>
						<?php else: ?>
							<!-- <a href="<?php echo U('Login/index');?>">Sign In</a> --><?php endif; ?>
					</ul>
					<div class="cart1">	
						<a class="popup-with-zoom-anim"  href="#small-dialog">BUY NOW</a>
					</div>
				</div>
			</div><?php endforeach; endif; ?>
			</div>
			<script>
				$(".popup-with-zoom-anim").click(function(){
					//商品名称及价格
					var name=$(this).parents('.pricing-grid1').children(".price-value").children('#name').val();
					var price=$(this).parents('.pricing-grid1').children(".price-value").children('#price').val();
					var gid=$(this).parents('.pricing-grid1').children(".price-value").children('#gid').val();
				   $("#goodname").html(name);
				   $("#goodprice").html(price);
				   $("#gid1").val(gid);
				  $.ajax({
			             type: "post",
			             url: "<?php echo U('Cart/doaction');?>",
			             data: {goodid:gid},
			             dataType: "json",
			             success: function(json){
			             	if(json.status == 'no'){
			             		layer.open({
					              content: json.message,
					              style: 'background-color:#313131; color:white; border:none;text-align:center',
					              time: 2
					             });
								 time = 1;
			                     newing = setInterval(function(){
			                     time--;
			                    if(time == -1){
			                      clearInterval(newing);
			                      location.href = "<?php echo U('Login/index');?>";
			                    }
			                 },1000);
			             		
							}else{
								   layer.open({
				                   content: json.message,
				                   style: 'background-color:#313131; color:white; border:none;text-align:center',
				                   time: 2
			                	})  
							}     
			             }
			         });
				})	
			</script>
				<div class="clear"> </div>

				<!--pop-up-grid-->
					 <div id="small-dialog" class="mfp-hide">
						<div class="pop_up">
						 	<div class="payment-online-form-left">
								<form action="<?php echo U('cart/docart');?>" method="post">
									<h4><span class="shipping"> </span>Confirm the order</h4>
									<ul>
										<input type="hidden" id="gid1" value="" name="goodid">
										<li><span id="goodname"></span></li>
										<li><span id="goodprice">$</span></li>
										<li><input type="text" name="goodneednum" value="Please enter the number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Company Name';}"></li>
									</ul>
									<div class="clear"> </div>
								    <ul class="payment-sendbtns">
										<li><input type="reset" value="Cancle"></li>
										<li><input type="submit" value="Purchase"></li>
									</ul>
									<div class="clear"> </div>
								</form>
							</div>
			  			</div>
					</div>
				</div>
			<div class="clear"> </div>
		</div>
	</div>
			<div class="pricing-plans">
				 <div class="wrap">
				 	<div class="price-head">	
				 		<h3>If You Want To Buy,Please Contect Us</h3>
				 	</div>
					<div class="salesinfo">
					<?php if(is_array($res)): foreach($res as $key=>$vo1): ?><div class="salesinfo1">
						<div class="salesinfo2">
							<ul>
								<li><img src="/thinkphp/Public/img/<?php echo ($vo1["pic"]); ?>" width="180px" height="180px"></li>
							</ul>
						</div>
						<div class="salesinfo3">
							<div class="sales">
								<div class="sales1">Name：</div><div class="sales2"><?php echo ($vo1["username"]); ?></div>
						    </div>
							<div class="sales">
								<div class="sales1">Tele：</div><div class="sales2"><?php echo ($vo1["phone"]); ?></div>
							</div>
							<div class="sales">
								<div class="sales1">Email：</div><div class="sales2"><?php echo ($vo1["email"]); ?></div>
							</div>
							<div class="sales">
								<div class="sales1">Locate：</div><div class="sales2"><?php echo ($vo1["address"]); ?></div>
							</div>
						</div>					
					</div><?php endforeach; endif; ?>
					</div>
					<div class="clear"> </div>
				</div>
			</div>
			<div class="bottom">
				Designed By ...
			</div>
</body>
</html>
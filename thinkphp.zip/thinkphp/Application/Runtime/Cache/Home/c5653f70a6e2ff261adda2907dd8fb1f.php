<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>主要内容区main</title>
    <link href="/thinkphp/Public/Admin/css/css.css" type="text/css" rel="stylesheet" />
    <link href="/thinkphp/Public/Admin/css/main.css" type="text/css" rel="stylesheet" />
    <link href="/thinkphp/Public/Admin/css/style_info.css" type="text/css" rel="stylesheet" />
    <link rel="shortcut icon" href="/thinkphp/Public/Admin/images/main/favicon.ico" />
</head>
  <body>
    <!--main_top-->
    <table width="99%" border="0" cellspacing="0" cellpadding="0" id="searchmain">
      <tr>
        <td width="99%" align="left" valign="top">您的位置：用户详细信息&nbsp;&nbsp;>&nbsp;&nbsp;编辑信息</td>
      </tr>
      <tr>
        <td align="left" valign="top" id="addinfo">
       
        </td>
      </tr>
     <tr>
    <td align="left" valign="top">
    <form method="post" action="<?php echo U('AdminIndex/doaction');?>" enctype="multipart/form-data">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="main-tab">
      <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">
        <td align="right" valign="middle" class="borderright borderbottom bggray">ID：</td>
        <td align="left" valign="middle" class="borderright borderbottom main-for">
        <input type="text"  name="id" value="<?php echo ($list["uid"]); ?>" class="text-word">
        </td>
      </tr>
       <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">
        <td align="right" valign="middle" class="borderright borderbottom bggray">真实姓名：</td>
        <td align="left" valign="middle" class="borderright borderbottom main-for">
        <input type="text"  name="username" value="<?php echo ($list1["username"]); ?>" class="text-word">
        </td>
       <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">
         <td align="center" valign="middle" class="borderright borderbottom"><img style='width:150px;height:75px' src='/thinkphp/Public/img/<?php echo ($list["pic"]); ?>'></td>
         <input type="file" class="form-control" multiple="true"  name="pic"/>            
       </tr>
      </tr>
       <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">
        <td align="right" valign="middle" class="borderright borderbottom bggray">手机号码：</td>
        <td align="left" valign="middle" class="borderright borderbottom main-for">
        <input type="text"  name="phone" value="<?php echo ($list["phone"]); ?>" class="text-word">
        
        </td>
      </tr>
       <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">
        <td align="right" valign="middle" class="borderright borderbottom bggray">电子邮箱：</td>
        <td align="left" valign="middle" class="borderright borderbottom main-for">
        <input type="text"  name="email" value="<?php echo ($list["email"]); ?>" class="text-word">
      
      </tr>
       <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">
        <td align="right" valign="middle" class="borderright borderbottom bggray">cardID：</td>
        <td align="left" valign="middle" class="borderright borderbottom main-for">
        <input type="text"  name="cardid" value="<?php echo ($list["cardid"]); ?>" class="text-word">
       
        </td>
      </tr>
      <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">
        <td align="right" valign="middle" class="borderright borderbottom bggray">住址:</td>
        <td align="left" valign="middle" class="borderright borderbottom main-for">
        <input type="text"  name="address" value="<?php echo ($list["address"]); ?>" class="text-word">
       
        </td>
      </tr>
      <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">
        <td align="right" valign="middle" class="borderright borderbottom bggray">&nbsp;</td>
        <td align="left" valign="middle" class="borderright borderbottom main-for">
        <input name="" type="submit" value="提交" class="text-but">
        <input name="" type="reset" value="重置" class="text-but"></td>
        </tr>
      </form>
    </table>
  </body>
</html>
<?php if (!defined('THINK_PATH')) exit();?>
		<div class="reg_top">
			<div class="l"><font color="red"><b>|</b></font><b>&nbsp;注册</b></div>
			<div class="r">已有帐号？<font color="red"><a href="<?php echo U('Login/index');?>">立即登录></a></font></div>		

			<div class="center">
				<form action="<?php echo U('Register/logregister');?>" method="post" >
					   
		            手机号:
		            <input style="" type="text"   class="" name="username" id="phone" autocomplete="off" placeholder="请输入手机号" >
			        密 码:
			        <input  type="password" class="" placeholder="请输入密码"  name="password" id="password" autocomplete="off">
			        确认密码:
			        <input  type="password" class="" placeholder="请再次输入密码"  name="repassword" id="repassword" autocomplete="off">
			        <input id="regSubBtn" type="submit" class="Rsubmit" value="注册" >
			        <input  type="reset" class="Rsubmit" value="重置" >

				</form>
			</div>
	    </div>
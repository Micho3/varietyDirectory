<?php if (!defined('THINK_PATH')) exit();?><html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>主要内容区main</title>
    <link href="/thinkphp/Public/Index/css/css.css" type="text/css" rel="stylesheet" />
    <link href="/thinkphp/Public/Index/css/main.css" type="text/css" rel="stylesheet" />
    <link href="/thinkphp/Public/Index/css/style_list.css" type="text/css" rel="stylesheet" />
    <link rel="shortcut icon" href="/thinkphp/Public/Admin/images/main/favicon.ico" />
    <script type="text/javascript" src="/thinkphp/Public/Index/js/layer.m.js"></script>
  </head>
<body>
<!--main_top-->
<table width="99%" border="0" cellspacing="0" cellpadding="0" id="searchmain">
  <tr>
    <td width="99%" align="left" valign="top">您的位置：账户管理&nbsp;&nbsp;>&nbsp;&nbsp;销售情况</td>
  </tr>
  <tr>
    <td align="left" valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="search">
      <tr>
       <td width="90%" align="left" valign="middle">
           <form method="get" action="">
           <span>管理员：</span>
           <input type="search" name="search" value="<?php echo $search?>" class="text-word">
           <input name="" type="submit" value="查询" class="text-but">
           </form>
         </td>
        <td width="10%" align="center" valign="middle" style="text-align:right; width:150px;">
          <a href="<?php echo U('User/main_info');?>" target="mainFrame" onFocus="this.blur()" class="add">新增管理员</a>
        </td>
      </tr>
  </table>
    </td>
  </tr>
  <tr>
    <td align="left" valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="main-tab">
        <tr>
            <th align="center" valign="middle" class="borderright">销售商品名称</th>
            <th align="center" valign="middle" class="borderright">销售商品单价</th>
            <th align="center" valign="middle" class="borderright">销售商品数量</th>
            <th align="center" valign="middle" class="borderright">总价</th>
        </tr>
<!--以下代码一会要循环使用-->
    <?php if(is_array($res)): foreach($res as $key=>$vo): ?><tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">   
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($vo['buyname']); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom">$<?php echo ($vo['buyprice']); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($vo['sum(buynum)']); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom">$<?php echo ($vo['buyprice']*$vo['sum(buynum)']); ?></td>
        <td align="center" valign="middle" class="borderbottom"> 
        </td>
      </tr><?php endforeach; endif; ?>               
    </table></td>
    </tr>
</table>
<br><br><br><br>
<h3>佣金提现</h3>
<form method="post" action="<?php echo U('Account/getthemonth');?>">
<table width="100%" border="0" cellspacing="0" cellpadding="0" id="main-tab">
        <tr>
            <th align="center" valign="middle" class="borderright">时间</th>
            <th align="center" valign="middle" class="borderright">用户名</th>
            <th align="center" valign="middle" class="borderright">销售套数</th>
            <th align="center" valign="middle" class="borderright">总金额</th>
            <th align="center" valign="middle" class="borderright">佣金</th>
            <th align="center" valign="middle" class="borderright">操作</th>
        </tr>
   <input type="hidden" value="<?php echo ($username); ?>" name="username">
   <input type="hidden" value="<?php echo ($total); ?>" name="num">
   <input type="hidden" value="<?php echo ($total*100); ?>" name="total">
   <input type="hidden" value="<?php echo ($pay); ?>" name="pay">
    <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">   
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($arrtime["firstday"]); ?>-<?php echo ($arrtime["lastday"]); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($username); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($total); ?>套</td>
        <td align="center" valign="middle" class="borderright borderbottom">$<?php echo ($total*100); ?></td>
        <td align="center" valign="middle" class="borderbottom">$<?php echo ($pay); ?></td>
        <?php if(($status==1)): ?><td>审核通过</td>
        <?php elseif(($status==2)): ?>
          <td>审核不通过</td>
        <?php elseif(($status==3)): ?>
          <td>审核中</td>
        <?php else: ?>
          <td><img src='/thinkphp/Public/Admin/images/main/pic6.gif'><button id="sub">申请提现</button></td><?php endif; ?>
      </tr>        
    </table>
    </tr>
    <script>
      $("#sub").click(function(){
        var res = $("form").serialize();
        $.ajax({
                   type: "post",
                   url: "<?php echo U('Account/getthemonth');?>",
                   data: res,
                   dataType: "json",
                   success: function(json){
                    if(json.status == 'no'){
                      layer.open({
                        content: json.message,
                        style: 'background-color:#313131; color:white; border:none;text-align:center',
                        time: 2
                       }); 
              }else{
                       layer.open({
                           content: json.message,
                           style: 'background-color:#313131; color:white; border:none;text-align:center',
                           time: 2
                        })  
              }     
                   }
               });

      })

    </script>
</table>
</form>
</body>
</html>
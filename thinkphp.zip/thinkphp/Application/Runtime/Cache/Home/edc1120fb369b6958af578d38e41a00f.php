<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>后台管理页面头部</title>
        <link href="/thinkphp/Public/Index/css/css.css" type="text/css" rel="stylesheet" />
    </head>
        <body onselectstart="return false" oncontextmenu=return(false) style="overflow-x:hidden;">
        <!--禁止网页另存为-->
        <noscript><iframe scr="*.htm"></iframe></noscript>
        <table width="100%" border="0" cellspacing="0" cellpadding="0" id="header">
          <tr>
              <td rowspan="2" align="left" valign="top" id="logo"></td>
            <td align="left" valign="bottom">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                      <td align="left" valign="bottom" id="header-name">Rifle.com</td>
                      <td align="right" valign="top" id="header-right">
                        <a href="<?php echo U('Login/logout');?>" target="topFrame" onFocus="this.blur()" class="admin-out">注销</a>
                        <a href="<?php echo U('AdminIndex/index');?>" target="_parent" onFocus="this.blur()" class="admin-home">管理首页</a>
                        <a href="<?php echo U('Home/Index/index');?>" target="_parent" onFocus="this.blur()" class="admin-index">网站首页</a>       	
                          <!-- 日历 -->
                          <span>
                              <SCRIPT type=text/javascript src="js/clock.js"></SCRIPT>
                              <SCRIPT type=text/javascript>showcal();</SCRIPT>
                          </span>
                      </td>
                  </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td align="left" valign="bottom">
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                      <td align="left" valign="top" id="header-admin">后台管理系统</td>
                      <td align="left" valign="bottom" id="header-menu">
                      <a href="<?php echo U('AdminIndex/index');?>" target="_parent" onFocus="this.blur()" id="menuon">后台首页</a>
                      <a href="<?php echo U('User/index');?>" target="mainFrame" onFocus="this.blur()">会员中心</a>
                      <a href="<?php echo U('Category/index');?>" target="mainFrame" onFocus="this.blur()">账户管理</a>
                      </td>
                  </tr>
                </table></td>
            </tr>
      </table>
    </body>
</html>
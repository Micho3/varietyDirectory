<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>后台管理页面底部</title>
		<link href="/thinkphp/Public/Index/css/css.css" type="text/css" rel="stylesheet" />
		<style>
			#footer{font-size:12px;}
			.footer_pad{padding:7px 9px 5px 9px;}
		</style>
	</head>
		<body style="overflow-x:hidden; background:url('/thinkphp/Public/Admin/images/main/bottombg.jpg') repeat-x top left;" onselectstart="return false" oncontextmenu=return(false) >
			<table width="100%" border="0" cellspacing="0" cellpadding="0" id="footer">
			  <tr>
			    <td align="left" valign="middle" class="footer_pad">COPYRIGHT©2015    版权所有 Rifle </td>
			    <td align="right" valign="middle" class="footer_pad"><img src="/thinkphp/Public/Admin/images/main/why.gif" width="12" height="12" alt="疑问图标" align="absmiddle">&nbsp;&nbsp;如有疑问请您联系TEL：400-100-1000</td>
			  </tr>
			</table>
		</body>
</html>
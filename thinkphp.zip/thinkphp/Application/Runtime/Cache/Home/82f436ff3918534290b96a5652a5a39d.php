<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <head>
    <title>熊猫旅游-后台管理</title>
        <script src="/thinkphp/Public/Admin/js/prototype.lite.js" type="text/javascript"></script>
        <script src="/thinkphp/Public/Admin/js/moo.fx.js" type="text/javascript"></script>
        <script src="/thinkphp/Public/Admin/js/moo.fx.pack.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="/thinkphp/Public/Index/css/left.css">
        <style type="text/css">
            #login a{
              font-size: 15px;
              text-decoration: none;
            }
            #login a:link{
              color:white;
            }
            #login a:visited{
              color:white;
            }
            #login a:hover{
              color:#FF6600;
            }
        </style>
  </head>
        <body>
          <div id="left-top">
          <div><img src="/thinkphp/Public/Index/images/main/member.gif" width="44" height="44" /></div>
            <span>用户：<?php echo ($_SESSION['user']['username']); ?><br>角色：Salesman</span>
        </div>
          <table width="100%" height="280" border="0" cellpadding="0" cellspacing="0" bgcolor="#F2F0F5">
            <tr>
                <td width="194" valign="top"><div id="container">
                <h1 class="type"><a href="javascript:void(0)">会员中心</a></h1>
                <div class="content">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td><img src="/thinkphp/Public/Admin/images/main/menu_topline.gif" width="194" height="5" /></td>
                </tr>
            </table>
        <ul class="MM">
          <li><a href="<?php echo U('User/index',array('id'=>$_SESSION['user']['id']));?>" target="mainFrame" onFocus="this.blur()">我的信息</a></li>
        </ul>
      </div>
      <h1 class="type"><a href="javascript:void(0)">账户管理</a></h1>
      <div class="content">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><img src="/thinkphp/Public/Admin/images/main/menu_topline.gif" width="194" height="5" /></td>
          </tr>
        </table>
        <ul class="MM">
          <li><a href="<?php echo U('Account/index',array('id'=>$_SESSION['user']['id']));?>" target="mainFrame" onFocus="this.blur()">销售情况</a></li>
          <li><a href="<?php echo U('Account/account',array('id'=>$_SESSION['user']['id']));?>" target="mainFrame" onFocus="this.blur()">结算佣金</a></li>
        </ul>
      </div>
      </div>
        <script type="text/javascript">
            var contents = document.getElementsByClassName('content');
            var toggles = document.getElementsByClassName('type');
            var myAccordion = new fx.Accordion(
              toggles, contents, {opacity: true, duration: 400}
            );
            myAccordion.showThisHideOpen(contents[0]);
        </script>
        </td>
  </tr>
</table>
</body>
</html>
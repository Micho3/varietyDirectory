<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>Login/Register</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link href="/thinkphp/Public/Admin/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="/thinkphp/Public/Admin/css/font-awesome.min.css" />
    <link href="/thinkphp/Public/index/css/login.css" rel='stylesheet' type='text/css' />
	<link rel="stylesheet" href="/thinkphp/Public/Admin/css/ace.min.css" />
	<link rel="stylesheet" href="/thinkphp/Public/Admin/css/ace-rtl.min.css" />
	<script>
     //    function changePic(){
     //       document.getElementById('code').src="<?php echo U('Code/index');?>"+"?"+Math.random(); 
     //    }
     //    function createXHR(){
     //        if(window.ActiveXObjecty){
     //            XHR = new ActiveXObject('Microsoft.XMLHTTP');                
     //        }else{
     //            XHR = new XMLHttpRequest();
     //        }
     //    }
     //    function checkUserName(){
     //        var username = window.document.getElementById('username').value;
     //        var flag = true;
     //        if(username==''){
     //            document.getElementById('namemsg').innerHTML = "用户名不能为空！";
     //            document.getElementById('submitReg').disabled = true;
     //        }else{
     //            document.getElementById('namemsg').innerHTML = "";
     //            document.getElementById('submitReg').disabled = false;
     //        }
     //        if(!flag){
     //            return false;
     //        }else{
     //            createXHR();
     //            XHR.open('POST',"<?php echo U('Login/checkUserName');?>",true);
     //            XHR.setRequestHeader('Content-type','application/x-www-form-urlencoded');
     //            var data ="username="+username;
     //            XHR.send(data);
     //            XHR.onreadystatechange=callback;
     //            return false;
     //        }
     //    }
     //    function callback(){
     //        if(XHR.readyState==4){
     //            if(XHR.status == 200){
     //                var textHtml = JSON.parse(XHR.responseText);
     //                if(textHtml.msg == "传值错误"){
     //                    alert(textHtml.msg);
     //                    document.getElementById('submitReg').disabled = true;
     //                }else if(textHtml.error){
     //                    document.getElementById('namemsg').innerHTML = textHtml.msg;
     //                    document.getElementById('submitReg').disabled = true;
     //                }else{
     //                    document.getElementById('namemsg').innerHTML ='<span style="color:green">'+textHtml.msg+'</span>';
     //                    document.getElementById('submitReg').disabled = false;
     //                }
     //            }
     //        }
     //    }
     //    function checkpass1(){
     //        if(document.getElementById('pass1').value==''){
     //            document.getElementById('pass1msg').innerHTML = '密码不能为空！';
     //            document.getElementById('submitReg').disabled = true;
     //        }else{
     //            document.getElementById('pass1msg').innerHTML = '&nbsp;';
     //            document.getElementById('submitReg').disabled = false;
     //        }
     //    }
     //    function checkpass2(){
     //        var pass1 = document.getElementById('pass1').value;
     //        var pass2 = document.getElementById('pass2').value;
     //        if(pass1 != pass2){
     //            document.getElementById('pass2msg').innerHTML = '两次密码输入不一致！';
     //            document.getElementById('submitReg').disabled = true;
     //        }else{
     //            document.getElementById('pass2msg').innerHTML = '';
     //            document.getElementById('submitReg').disabled = false;
     //        }
     //    }
     //    function checkPhoneNum(){
     //        var ss=document.getElementById('phoneNum').value;
     //        var re=/^(1[3785479][0-9]{9})|(15[89][0-9]{8})$/;
     //        if(re.test(ss)) {
     //            document.getElementById('telmsg').innerHTML="";   
     //            document.getElementById('submitReg').disabled=false; 
     //        }else{
     //            document.getElementById('telmsg').innerHTML="请输入正确的手机号码！";
     //            document.getElementById('submitReg').disabled=true; 
     //        }
     //    }
    	// function checkform(){
	    //     var flag = true;
	    //     var pass1 = document.getElementById('pass1').value;
	    //     var pass2 = document.getElementById('pass2').value;
	    //     if(pass1 != pass2){
	    //         document.getElementById('pass2msg').innerHTML = '两次密码输入不一致！';
	    //         var flag = false;
	    //     }
	    //     createXHR();
	    //     XHR.open('POST',"<?php echo U('Login/checkRegisterCode');?>",true);
	    //     XHR.setRequestHeader('Content-type','application/x-www-form-urlencoded');
	    //     var data ="code="+document.getElementById('codeText').value;
	    //     XHR.send(data);
	    //     XHR.onreadystatechange=checkCode;
	    //     if(flag){
	    //         return true;
	    //     }else{
	    //         return false;
	    //     }
	    // }
	    // function checkCode(){
	    //     if(XHR.readyState==4){
	    //         if(XHR.status == 200){
	    //             var code = JSON.parse(XHR.responseText);
	    //             if(!code.status){
	    //                 flag = false;
	    //                 document.getElementById('codemsg').innerHTML = code.msg;
	    //             }else{
	    //                 document.getElementById('codemsg').innerHTML = '';
	    //             }
	    //         }
	    //     }
	    // }
    </script>
</head>
	<body class="login-layout">
		<div class="main-container">
			<div class="main-content">
				<div class="row">
					<div class="col-sm-10 col-sm-offset-1">
						<div class="login-container">
							<div class="center">
								<h1>
									<span class="white"><font color="#FF6600"><a href="<?php echo U('Index/index');?>">Rifle</a></font></span>
								</h1>
								<h4 class="blue">&copy;Login/Register</h4>
							</div>
							<div class="space-6"></div>
							<div class="position-relative">
								<div id="login-box" class="login-box visible widget-box no-border">
									<div class="widget-body">
										<div class="widget-main">
											<h4 class="header blue lighter bigger">
												Sign In
											</h4>
											<div class="space-6"></div>
											<form action="<?php echo U('Login/loglogin');?>" method="post" id="loginForm">
												<fieldset>
													<label class="block clearfix">
														<span class="block input-icon input-icon-right">
															<input type="text" class="form-control" placeholder="Username"  name="username" id="loginUserNameInput" />
															<div id="a"><img src="/thinkphp/Public/Index/images/one4.jpg"></div>
														</span>
														<font id="loginUserNameTips" color='red'></font>
													</label>
													<label class="block clearfix">
														<span class="block input-icon input-icon-right">
															<input type="password" class="form-control" placeholder="Password" name="password" id="loginPassInput" />
															<div id="a"><img src="/thinkphp/Public/Index/images/one5.jpg"></div>
														</span>
														<font id="loginPassTips" color="red"></font>
													</label>

													<div class="space"></div>

													<div class="clearfix">
														
														<button type="submit" class="width-35 pull-right btn btn-sm btn-primary">
															Sign In
														</button>
													</div>

													<div class="space-4"></div>
												</fieldset>
											</form>

											<div class="social-or-login center">
												<span class="bigger-110">Or Login Using</span>
											</div>

										
										</div><!-- /widget-main -->

										<div class="toolbar clearfix">
										

											<div>
												<a href="#" onclick="show_box('signup-box'); return false;" class="user-signup-link">
													Reg Now
													<!-- <i class="icon-arrow-right"></i> -->
												</a>
											</div>
										</div>
									</div><!-- /widget-body -->
								</div><!-- /login-box -->

								<div id="forgot-box" class="forgot-box widget-box no-border">
									<div class="widget-body">
										<div class="widget-main">
											<h4 class="header red lighter bigger">
												<i class="icon-key"></i>
												Retrieve Password
											</h4>

											<div class="space-6"></div>
											<p>
												Enter your email and to receive instructions
											</p>

											<form>
												<fieldset>
													<label class="block clearfix">
														<span class="block input-icon input-icon-right">
															<input type="email" class="form-control" placeholder="Email" name="email"/ >
															<i class="icon-envelope"></i>
														</span>
													</label>

													<div class="clearfix">
														<button type="button" class="width-35 pull-right btn btn-sm btn-danger">
															<i class="icon-lightbulb"></i>
															Send Me!
														</button>
													</div>
												</fieldset>
											</form>
										</div><!-- /widget-main -->

										<div class="toolbar center">
											<a href="#" onclick="show_box('login-box'); return false;" class="back-to-login-link">
												Back to login
												<i class="icon-arrow-right"></i>
											</a>
										</div>
									</div><!-- /widget-body -->
								</div><!-- /forgot-box -->

								<div id="signup-box" class="signup-box widget-box no-border">
									<div class="widget-body">
										<div class="widget-main">
											<h4 class="header green lighter bigger">
												<!-- <i class="icon-group blue"></i> -->
												Register
											</h4>

								<div class="space-6"></div>
								<p> Salesperson Information: </p>

								<form enctype="multipart/form-data" action="<?php echo U('Register/logregister');?>" method="post">
									<fieldset>
										<label class="block clearfix">
											<span class="block input-icon input-icon-right"><!-- onblur='checkUserName()' -->
												<input type="text"  id='username' class="form-control"   placeholder="Username" name="username"/>
												<div id="a"><img src="/thinkphp/Public/Index/images/one4.jpg"></div>
											</span>
											<font id="userRegTips"></font>
										</label>

										<label class="block clearfix">
											<span class="block input-icon input-icon-right">
												<input type="password" id='pass1' class="form-control" placeholder="Password" name="password"/>
												<div id="a"><img src="/thinkphp/Public/Index/images/one5.jpg"></div>
											</span>
										</label>

										<label class="block clearfix">
											<span class="block input-icon input-icon-right">
												<input type="password" id='pass2'  class="form-control" placeholder="Password Again" name="repassword"/>
												<div id="a"><img src="/thinkphp/Public/Index/images/one5.jpg"></div>
											</span>
										</label>
										<label class="block clearfix">
											<span class="block input-icon input-icon-right">
												<input type="text" class="form-control" placeholder="Telephonenumber" name="phone"/>
												<div id="a"><img src="/thinkphp/Public/Index/images/one6.jpg"></div>
											</span>
										</label>
										<label class="block clearfix">
											<span class="block input-icon input-icon-right">
												<input type="text" class="form-control" placeholder="cardid" name="cardid"/>
												<div id="a"><img src="/thinkphp/Public/Index/images/one6.jpg"></div>
											</span>
										</label>
										<label class="block clearfix">
											<span class="block input-icon input-icon-right">
												<input type="text" class="form-control" placeholder="Email" name="email"/>
												<div id="a"><img src="/thinkphp/Public/Index/images/main/icon-mail2.gif"></div>
											</span>
										</label>
										<label class="block clearfix">
											<span class="block input-icon input-icon-right">
												<input type="text" class="form-control" placeholder="Address" name="address"/>
												<div id="a"><img src="/thinkphp/Public/Index/images/main/to.gif"></div>
											</span>
										</label>
											<label class="block clearfix">
											<span class="block input-icon input-icon-right">
												<input type="file" class="form-control" multiple="true"  name="pic"/>
												<div id="a"><img src="/thinkphp/Public/Index/images/main/yc.gif"></div>
											</span>
										</label>
										<div class="space-24"></div>
										<div class="clearfix">
											<button type="reset" class="width-30 pull-left btn btn-sm">
												<!-- <i class="icon-refresh"></i> -->
												Cancle
											</button>

											<button type="submit" class="width-65 pull-right btn btn-sm btn-success">
												Register
												<!-- <i class="icon-arrow-right icon-on-right"></i> -->
											</button>
										</div>
									</fieldset>
								</form>
							</div>

							<div class="toolbar center">
								<a href="#" onclick="show_box('login-box'); return false;" class="back-to-login-link">
									<!-- <i class="icon-arrow-left"></i> -->
									Back to Login
								</a>
										</div>
									</div><!-- /widget-body -->
								</div><!-- /signup-box -->
							</div><!-- /position-relative -->
						</div>
					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
		</div><!-- /.main-container -->

		<!-- basic scripts -->

		<!--[if !IE]> -->

		<script src="/thinkphp/Public/Admin/js/jquery.min.js"></script>


		<script type="text/javascript">
			window.jQuery || document.write("<script src='/thinkphp/Public/Admin/js/jquery-2.0.3.min.js'>"+"<"+"/script>");
		</script>



		<script type="text/javascript">
			if("ontouchend" in document) document.write("<script src='/thinkphp/Public/Admin/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>

		<!-- inline scripts related to this page -->

		<script type="text/javascript">
			function show_box(id) {
			 jQuery('.widget-box.visible').removeClass('visible');
			 jQuery('#'+id).addClass('visible');
			}
		</script>
		<script src="/thinkphp/Public/Common/jquery-1.11.3.min.js"></script>
		<!--登录\注册验证-->
		<script>
		$(document).ready(function(){
			//登陆验证用户名与密码是否为空
			function checkInputNotNull(input,tips,info){
				var loginFlag = true;
				if (input.val()=='') {
					$(tips).html(info);
					loginFlag = false;
				}else{
					$(tips).html('');
				}
				return
			}
			//只在表单提交时做验证
			$("#loginForm").submit(function(){
				var user = checkInputNotNull($("#loginUserNameInput"),"#loginUserNameTips",'用户名未填写！');
				var pass = checkInputNotNull($("#loginPassInput"),"#loginPassTips",'密码未填写！');
				if(user&&pass){
					return true;
				}else{
					return false;
				}
			});
			//注册时的js验证
			function checkNotNull(obj){
				if(obj.val()==''){
					return false;
				}else{
					return true;
				}
			}
			function checkRegUser(){
				var usernull = checkNotNull($('#username'));
				var username = $('#username').val();
				alert("adad");
				if(usernull){
					var url = "/thinkphp/index.php/Login/isUserExists";
					$.ajax({
						url:url,
						data:{
							user:username,
						},
						type:'post',
						dataType:"json",
						success:function(qwe){
							if(qwe.status == 1){
								$('#userRegTips').html(qwe.msg);
								$('#userRegTips').css('color','green');
							}else{
								$('#userRegTips').html(qwe.msg);
								$('#userRegTips').css('color','red');
							}
						},
						error:function(qwe){
            				alert(qwe.msg);
            				return false;
        				}
					});
				}else{

				}
			}
			$('#username').blur(function(){
				checkRegUser();
			});
		});
		</script>
	</body>
</html>
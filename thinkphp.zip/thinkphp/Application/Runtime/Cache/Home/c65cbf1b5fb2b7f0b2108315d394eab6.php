<?php if (!defined('THINK_PATH')) exit();?><html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>主要内容区main</title>
    <link href="/thinkphp/Public/Index/css/css.css" type="text/css" rel="stylesheet" />
    <link href="/thinkphp/Public/Index/css/main.css" type="text/css" rel="stylesheet" />
    <link href="/thinkphp/Public/Index/css/style_list.css" type="text/css" rel="stylesheet" />
    <link rel="shortcut icon" href="/thinkphp/Public/Admin/images/main/favicon.ico" />
  </head>
<body>
<!--main_top-->
<table width="99%" border="0" cellspacing="0" cellpadding="0" id="searchmain">
  <tr>
    <td width="99%" align="left" valign="top">您的位置：账户管理&nbsp;&nbsp;>&nbsp;&nbsp;销售情况</td>
  </tr>
  <tr>
    <td align="left" valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="search">
  		<tr>
   		 <td width="90%" align="left" valign="middle">
       <!--
          // /*****************加入搜索功能**************/
          //   if(isset($_GET['search'])){
          //       $search=$_GET['search'];
          //       $where="where username like '%<?php echo ($search); ?>%' ";
          //   }else{
          //       $search='';
          //       $where='';
          //   }
       ?-->
	         <form method="get" action="">
	         <span>管理员：</span>
	         <input type="search" name="search" value="<?php echo $search?>" class="text-word">
	         <input name="" type="submit" value="查询" class="text-but">
	         </form>
         </td>
  		  <td width="10%" align="center" valign="middle" style="text-align:right; width:150px;">
          <a href="<?php echo U('User/main_info');?>" target="mainFrame" onFocus="this.blur()" class="add">新增管理员</a>
        </td>
  		</tr>
	</table>
    </td>
  </tr>
  <tr>
    <td align="left" valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="main-tab">
        <tr>
            <th align="center" valign="middle" class="borderright">商品名称</th>
            <th align="center" valign="middle" class="borderright">数量</th>
            <th align="center" valign="middle" class="borderright">价格</th>
            <th align="center" valign="middle" class="borderright">销售时间</th>
            <th align="center" valign="middle" class="borderright">销售地点</th>
        </tr>
<!--以下代码一会要循环使用-->
  <?php if(is_array($row)): $i = 0; $__LIST__ = $row;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">   
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($vo["buyname"]); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($vo["buynum"]); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"> <?php echo ($vo["buyprice"]); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo (date("Y-m-d H:i:s",$vo["addtime"])); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($vo["address"]); ?></td>
      </tr><?php endforeach; endif; else: echo "" ;endif; ?>
    </table></td>    
    </tr>
  <tr>
    <td><?php echo ($page); ?></td>
  </tr>
</table>
</body>
</html>
<?php if (!defined('THINK_PATH')) exit();?><html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>主要内容区main</title>
    <link href="/thinkphp/Public/Index/css/css.css" type="text/css" rel="stylesheet" />
    <link href="/thinkphp/Public/Index/css/main.css" type="text/css" rel="stylesheet" />
    <link href="/thinkphp/Public/Index/css/style_list.css" type="text/css" rel="stylesheet" />
    <link rel="shortcut icon" href="/thinkphp/Public/Admin/images/main/favicon.ico" />
  </head>
<body>
<!--main_top-->
<table width="99%" border="0" cellspacing="0" cellpadding="0" id="searchmain">
  <tr>
    <td width="99%" align="left" valign="top">您的位置：会员中心&nbsp;&nbsp;>&nbsp;&nbsp;我的信息</td>
  </tr>
  <tr>
    <td align="left" valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="search">
  		<tr>
   		 <td width="90%" align="left" valign="middle">
       <!--
          // /*****************加入搜索功能**************/
          //   if(isset($_GET['search'])){
          //       $search=$_GET['search'];
          //       $where="where username like '%<?php echo ($search); ?>%' ";
          //   }else{
          //       $search='';
          //       $where='';
          //   }
       ?-->
	         <form method="get" action="">
	         <span>管理员：</span>
	         <input type="search" name="search" value="<?php echo $search?>" class="text-word">
	         <input name="" type="submit" value="查询" class="text-but">
	         </form>
         </td>
  		  <td width="10%" align="center" valign="middle" style="text-align:right; width:150px;">
          <a href="<?php echo U('User/main_info');?>" target="mainFrame" onFocus="this.blur()" class="add">新增管理员</a>
        </td>
  		</tr>
	</table>
    </td>
  </tr>
  <tr>
    <td align="left" valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="main-tab">
        <tr>
            <th align="center" valign="middle" class="borderright">编号</th>
            <th align="center" valign="middle" class="borderright">头像</th>
            <th align="center" valign="middle" class="borderright">真实姓名</th>
            <th align="center" valign="middle" class="borderright">手机号码</th>
            <th align="center" valign="middle" class="borderright">电子邮件</th>
            <th align="center" valign="middle" class="borderright">证件号码</th>
            <th align="center" valign="middle" class="borderright">状态</th>
            <th align="center" valign="middle" class="borderright">添加时间</th>
            <th align="center" valign="middle">操作</th>
        </tr>
<!--以下代码一会要循环使用-->
    <tr onMouseOut="this.style.backgroundColor='#ffffff'" onMouseOver="this.style.backgroundColor='#edf5ff'">   
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($list['uid']); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><img style='width:150px;height:75px' src='/thinkphp/Public/img/<?php echo ($list["pic"]); ?>'></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($list1["username"]); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($list["phone"]); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($list["email"]); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo ($list["cardid"]); ?></td>
        <td align="center" valign="middle" class="borderright borderbottom">
          	<?php switch($list1["islogin"]): case "1": ?>允许登陆<?php break;?>
              <?php case "0": ?><font color='silver'>禁止登陆</font><?php break; endswitch;?>
        </td>
         <td align="center" valign="middle" class="borderright borderbottom"><?php echo date('Y-m-d H:i:s',$list['addtime']);?></td>
        <td align="center" valign="middle" class="borderbottom">
            <a href="<?php echo U('AdminIndex/update',array('id'=>$list['id']));?>" target="mainFrame" onFocus="this.blur()" class="add"><img src="/thinkphp/Public/Admin/images/main/pic9.gif">&nbsp;编辑</a>
        </td>
      </tr>
    </table></td>
    </tr>
  <tr>
    <td><?php echo ($page); ?></td>
  </tr>
</table>
</body>
</html>
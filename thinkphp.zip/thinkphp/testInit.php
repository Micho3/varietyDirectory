<?php
if (!defined('SIMPLETEST_SETUP')){
    define('SIMPLETEST_RUN_UNKNOWN',0);
    define('SIMPLETEST_RUN_UNIT',1);
    define('SIMPLETEST_RUN_GROUP',2);
    define('SIMPLETEST_RUN_GLOBAL',3);
    $simletest_run = SIMPLETEST_RUN_UNKNOWN;
    define('SIMPLETEST_DIR', './simpletest');
    define('SYS_ROOT', dirname(__FILE__) . '/..');
    define('SIMPLETEST_SETUP', true);
    require SIMPLETEST_DIR . '/unit_tester.php';
    require SIMPLETEST_DIR . '/reporter.php';
}
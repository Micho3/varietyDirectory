
教程 http://drupalchina.cn/simpletest
1.测试文件包含在每个需要测试的文件夹下，测试文件以及文件夹以Test为后缀与源文件区分
2.根目录下的testInit.php用于引入相关的测试文件以及规定常量